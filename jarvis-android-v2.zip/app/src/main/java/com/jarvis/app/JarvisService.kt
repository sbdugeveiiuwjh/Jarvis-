package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

class JarvisService : AccessibilityService(), TextToSpeech.OnInitListener {
    companion object { var instance: JarvisService? = null }

    private var tts: TextToSpeech? = null
    private var wm: WindowManager? = null
    private var btn: TextView? = null
    private var rec: SpeechRecognizer? = null
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var always = false
    @Volatile private var speaking = false
    @Volatile private var listening = false

    override fun onServiceConnected() {
        instance = this
        tts = TextToSpeech(this, this)
        addButton()
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("hi", "IN")
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true }
            override fun onDone(utteranceId: String?) { speaking = false; ui.post { startRec() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { speaking = false; ui.post { startRec() } }
        })
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        try { btn?.let { wm?.removeView(it) } } catch (e: Exception) {}
        rec?.destroy()
        tts?.shutdown()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun addButton() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "J"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#1D6FE0")) }
        }
        val p = WindowManager.LayoutParams(
            150, 150,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 20
        p.y = 600
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    p.x = ox + dx; p.y = oy + dy
                    wm?.updateViewLayout(b, p)
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggle(); true }
                else -> false
            }
        }
        wm?.addView(b, p)
        btn = b
    }

    private fun setListening(on: Boolean) {
        (btn?.background as? GradientDrawable)?.setColor(Color.parseColor(if (on) "#2E9E4F" else "#1D6FE0"))
    }

    private fun say(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") }

    private fun toggle() {
        if (always) {
            always = false
            listening = false
            rec?.destroy()
            setListening(false)
            say("Jarvis band")
            return
        }
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty()) { say("Pehle Jarvis app mein Gemini key daalo"); return }
        always = true
        setListening(true)
        say("Jarvis chalu, boliye")
        ui.postDelayed({ speaking = false; startRec() }, 4000)
    }

    private fun startRec() {
        if (!always || speaking || listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { always = false; setListening(false); say("Voice input available nahi hai"); return }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                listening = false
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) process(t) else ui.postDelayed({ startRec() }, 300)
            }
            override fun onError(error: Int) {
                listening = false
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    always = false; setListening(false); say("Pehle Jarvis app mein mic permission Allow karo"); return
                }
                ui.postDelayed({ startRec() }, 800)
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        rec = r
        listening = true
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        )
    }

    private fun process(cmd: String) {
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        Thread {
            val j = try { Gemini.ask(key, cmd) } catch (e: Exception) {
                JSONObject().put("action", "chat").put("reply", "Net ya key ki dikkat hai")
            }
            ui.post {
                say(Router.run(this, j))
                ui.postDelayed({ speaking = false; startRec() }, 6000)
            }
        }.start()
    }

    fun tapText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) { x.performAction(AccessibilityNodeInfo.ACTION_CLICK); return true }
                x = x.parent
            }
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = findScrollable(root) ?: return false
        return n.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }
}
