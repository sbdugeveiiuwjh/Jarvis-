package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    private const val SYSTEM = """You are Jarvis, an Android phone assistant. The user speaks Hindi, English or Hinglish. Reply ONLY with one JSON object and no other text. Fields: action, name, number, text, app, query, steps, reply. action is one of: call, open_app, whatsapp_draft, sms_draft, search_web, tap_text, type_text, scroll_down, scroll_up, back, home, recents, notifications, wake_screen, chat. name is a contact name, number is digits, text is message text or text to tap or type, app is an app name, query is a web search. reply is a short friendly Hinglish sentence to speak aloud. For tasks that need several actions, put them in steps as an array of objects with the same fields (no nested steps). You cannot unlock the phone, never claim to. For messages only make a draft, the user presses send."""

    private val MODELS = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash")

    fun ask(key: String, cmd: String): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", cmd)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        var last = 0
        for (m in MODELS) {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code == 200) {
                val resp = JSONObject(c.inputStream.bufferedReader().readText())
                var text = resp.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                text = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                return JSONObject(text)
            }
            last = code
        }
        return JSONObject().put("action", "chat").put("reply", "Gemini error $last, key check karo")
    }
}
