package com.jarvis.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import org.json.JSONObject

private fun Context.go(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

object Router {
    fun run(a: Context, j: JSONObject): String {
        val reply = j.optString("reply", "Ho gaya")
        val steps = j.optJSONArray("steps")
        if (steps != null && steps.length() > 0) {
            for (i in 0 until steps.length()) {
                Handler(Looper.getMainLooper()).postDelayed({
                    try { runOne(a, steps.getJSONObject(i)) } catch (e: Exception) {}
                }, i * 2500L)
            }
            return reply
        }
        return try { runOne(a, j) ?: reply } catch (e: Exception) { "Error: ${e.message}" }
    }

    // returns an error reply, or null if fine
    private fun runOne(a: Context, j: JSONObject): String? {
        val svc = JarvisService.instance
        val need = "Pehle Accessibility me Jarvis ON karo"
        val text = j.optString("text")
        when (j.optString("action")) {
            "call" -> {
                val num = number(a, j) ?: return "Number nahi mila"
                val granted = a.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                a.go(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num")))
            }
            "open_app" -> {
                val want = j.optString("app").lowercase()
                val pm = a.packageManager
                val l = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val hit = pm.queryIntentActivities(l, 0).firstOrNull {
                    it.loadLabel(pm).toString().lowercase().contains(want)
                } ?: return "App nahi mila"
                a.go(pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "App nahi mila")
            }
            "whatsapp_draft" -> {
                val num = number(a, j)?.filter { it.isDigit() }
                if (num != null) {
                    val full = if (num.length == 10) "91$num" else num
                    a.go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$full?text=" + Uri.encode(text))))
                } else {
                    a.go(Intent(Intent.ACTION_SEND).setType("text/plain")
                        .setPackage("com.whatsapp").putExtra(Intent.EXTRA_TEXT, text))
                }
            }
            "sms_draft" -> {
                val num = number(a, j) ?: ""
                a.go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", text))
            }
            "search_web" -> a.go(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=" + Uri.encode(j.optString("query")))))
            "tap_text" -> { if (svc == null) return need; if (!svc.tapText(text)) return "Screen par '$text' nahi mila" }
            "type_text" -> { if (svc == null) return need; if (!svc.typeText(text)) return "Koi text box select nahi hai" }
            "scroll_down" -> { if (svc == null) return need; svc.scroll(true) }
            "scroll_up" -> { if (svc == null) return need; svc.scroll(false) }
            "back" -> { if (svc == null) return need; svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) }
            "home" -> { if (svc == null) return need; svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) }
            "recents" -> { if (svc == null) return need; svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS) }
            "notifications" -> { if (svc == null) return need; svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }
            "wake_screen" -> {
                @Suppress("DEPRECATION")
                val w = (a.getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "jarvis:wake")
                w.acquire(3000)
            }
        }
        return null
    }

    private fun number(a: Context, j: JSONObject): String? {
        val n = j.optString("number").filter { it.isDigit() || it == '+' }
        if (n.length >= 7) return n
        val name = j.optString("name")
        if (name.isEmpty() ||
            a.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = a.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        ) ?: return null
        c.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }
}
