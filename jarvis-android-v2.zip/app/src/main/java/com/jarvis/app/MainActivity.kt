package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.*
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var log: TextView
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }

        val key = EditText(this).apply {
            hint = "Gemini API key"
            setText(prefs.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val save = Button(this).apply {
            text = "Key save karo"
            setOnClickListener {
                prefs.edit().putString("key", key.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }
        val acc = Button(this).apply {
            text = "Accessibility ON karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val mic = Button(this).apply {
            text = "Bolo (mic)"
            setOnClickListener {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                try { startActivityForResult(i, 7) } catch (e: Exception) { say("Voice input available nahi hai, type karo") }
            }
        }
        val input = EditText(this).apply { hint = "Ya yahan command type karo" }
        val send = Button(this).apply {
            text = "Bhejo"
            setOnClickListener { val t = input.text.toString().trim(); if (t.isNotEmpty()) { input.setText(""); handle(t) } }
        }
        log = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 0) }

        for (v in listOf(key, save, acc, mic, input, send, log)) root.addView(v)
        setContentView(ScrollView(this).apply { addView(root) })

        requestPermissions(arrayOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onInit(status: Int) { tts.language = Locale("hi", "IN") }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { handle(it) }
        }
    }

    private fun handle(cmd: String) {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) { say("Pehle Gemini key daalo aur save karo"); return }
        log.append("Aap: $cmd\n")
        Thread {
            val j = try { Gemini.ask(key, cmd) } catch (e: Exception) {
                JSONObject().put("action", "chat").put("reply", "Net ya key ki dikkat hai")
            }
            runOnUiThread { say(Router.run(this, j)) }
        }.start()
    }

    private fun say(t: String) {
        log.append("Jarvis: $t\n\n")
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
    }
}
