JARVIS APK BANANE KE STEPS (Android Studio nahi chahiye)
1. github.com par free account, naya repository (naam: jarvis).
2. Files upload karo (folders ke saath) ya jarvis-copy-paste.txt se 7 files banao.
3. Actions tab > "Build APK" poora hone do (3-5 min).
4. Artifacts me "jarvis-apk" download karo, zip kholo, app-debug.apk install karo.
5. Settings > Apps > Jarvis > menu > "Allow restricted settings".
6. Jarvis kholo, permissions Allow, "Accessibility ON karo" > Jarvis ON.
7. aistudio.google.com se free Gemini key lo, app me daalo, "Key save karo".
8. Screen par neela "J" button dikhega. Dabao, bolo, ye kisi bhi app ke upar chalta hai.
9. Settings > Apps > Jarvis > Battery > Unrestricted karo.
NOTE: Phone unlock Android kisi app ko allow nahi karta.
